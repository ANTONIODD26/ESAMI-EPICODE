CREATE DATABASE ToysGroup;
CREATE TABLE Product (ProductID MEDIUMINT PRIMARY KEY,
					 ProductCategory VARCHAR(50),
                     ProductName VARCHAR(100),
                     UnitPrice DECIMAL(10,2));

CREATE TABLE Region (RegionID MEDIUMINT PRIMARY KEY,
					RegionName VARCHAR(50),
                    State VARCHAR(50));

 CREATE TABLE Sales (SalesOrderID MEDIUMINT PRIMARY KEY,
                    OrderDate DATE,
                    OrderQuantity INT,
                    Total DECIMAL(10,2),
                    ProductID MEDIUMINT,
                    FOREIGN KEY (ProductID) REFERENCES Product (ProductID),
                    RegionID MEDIUMINT,
                    FOREIGN KEY (RegionID) REFERENCES Region (RegionID));

INSERT INTO Product (ProductID, ProductCategory, ProductName, UnitPrice) VALUES (1, 'Role-Playing', 'Spada incantata', 12.99),
																				(2, 'Role-Playing', 'Kit dottore', 19.99),
                                                                                (3, 'Role-Playing', 'Stazione di polizia', 24.99),
                                                                                (4, 'Role-Playing', 'Trasformista magico', 17.99),
                                                                                (5, 'Role-Playing', 'Kit chef fantasia', 14.99),
                                                                                (6, 'Bambini', 'Orsetto abbraccione', 9.99),
                                                                                (7, 'Bambini', 'Puzzle colorato', 8.99),
                                                                                (8, 'Bambini', 'Macchina veloce', 11.99),
                                                                                (9, 'Bambini', 'Set costruzioni', 16.99),
                                                                                (10, 'Bambini', 'Cubetti morbidi', 7.99),
                                                                                (11, 'Avventura', 'Nave pirata', 29.99),
                                                                                (12, 'Avventura', 'Esploratore pirata', 21.99),
                                                                                (13, 'Avventura', 'Robot spaziale avanzato', 34.99),
                                                                                (14, 'Avventura', 'Carovana cowboy', 26.99),
                                                                                (15, 'Avventura', 'Aereo acrobatico', 18.99),
                                                                                (16, 'Artistici', 'Penna magica', 10.99),
                                                                                (17, 'Artistici', 'Set modellaggio', 13.99),
                                                                                (18, 'Artistici', 'Gioielli fai da te', 22.99),
                                                                                (19, 'Artistici', 'Pittore acquerello', 15.99),
                                                                                (20, 'Artistici', 'Adesivi creativi', 6.99);

INSERT INTO Region (RegionID, RegionName, State) VALUES 
														(1, 'Rochester', 'New York'),
														(2, 'Del Rio', 'Texas'),
														(3, 'Fort Meyers', 'Florida'),
														(4, 'Los Angeles', 'California'),
														(5, 'Rock Island', 'Illinois'),
														(6, 'Cleveland', 'Ohio'),
														(7, 'Boston', 'Massachusetts'),
														(8, 'Whashington DC', 'Washington'),
														(9, 'Blue Ridge', 'Georgia'),
														(10, 'Phoenix', 'Arizona'),
                                                        (11, 'Stoccolma', 'Sweden'),
														(12, 'Campania', 'Italy'),
														(13, 'Cracovia', 'Poland'),
														(14, 'Paris', 'France'),
														(15, 'Berlino', 'Germany'),
														(16, 'Amsterdam', 'Netherlands'),
														(17, 'Cusselord', 'Finland'),
														(18, 'Notthingam', 'United Kingdom'),
														(19, 'Atene', 'Greece'),
														(20, 'Sicily', 'Italy');
          
  

INSERT INTO Sales (SalesOrderID, OrderDate, OrderQuantity, ProductID, RegionID, Total) VALUES 
																							 (1, '2020-01-12', 3, 3, 12, 3*24.99),
                                                                                             (2, '2020-02-02', 2, 4, 13, 2*17.99),
                                                                                             (3, '2020-03-04', 5, 5, 14, 5*26.99),
                                                                                             (4, '2020-04-07', 1, 11, 20, 1*29.99),
                                                                                             (5, '2021-05-13', 2, 19, 12, 2*15.99),
                                                                                             (6, '2021-06-14', 1, 20, 20, 1*6.99),
                                                                                             (7, '2021-07-14', 2, 16, 11, 2*10.99),
                                                                                             (8, '2021-08-16', 2, 15, 10, 2*18.99),
                                                                                             (9, '2022-09-17', 3, 14, 12, 3*26.99),
                                                                                             (10,'2022-10-18', 1, 13, 20, 1*34.99),
                                                                                             (11, '2022-11-20', 1, 10, 7, 1*7.99),
                                                                                             (12, '2022-12-21', 3, 9, 4, 3*16.99),
                                                                                             (13, '2023-01-23', 1, 8, 6, 1*11.99),
                                                                                             (14, '2023-02-03', 3, 12, 20, 3*21.99),
                                                                                             (15, '2023-03-05', 1, 6, 1, 1*9.99),
                                                                                             (16, '2023-04-12', 2, 14, 12, 2*26.99),
                                                                                             (17, '2024-05-13', 4, 13, 20, 4*34.99),
                                                                                             (18, '2024-06-07', 1, 1, 15, 1*24.99),
                                                                                             (19, '2024-07-09', 2, 13, 12, 2*34.99),
                                                                                             (20, '2024-08-10', 1, 14, 18, 1*26.99),
                                                                                             (21, '2024-09-11', 1, 15, 2, 1*18.99),
                                                                                             (22, '2024-09-12', 2, 12, 8, 2*21.99),
                                                                                             (23, '2024-09-20', 1, 16, 9, 1*10.99),
                                                                                             (24, '2024-10-01', 1, 13, 16, 1*34.99),
                                                                                             (25, '2025-10-05', 1, 14, 17, 1*26.99),
                                                                                             (26, '2025-10-07', 2, 1, 3, 2*12.99),
                                                                                             (27, '2025-11-01', 1, 3, 5, 1*24.99),
                                                                                             (28, '2025-09-02', 1, 4, 18, 1*17.99),
                                                                                             (29, '2025-05-03', 1, 13, 19, 1*34.99);
                                                                                             
                                                                                             
-- 1. Verificare che i campi definiti come PK siano univoci.
SELECT pr.ProductID, sls.SalesOrderID, rg.RegionID,
       COUNT(*)
FROM product pr
INNER JOIN Sales sls
ON pr.ProductID = sls.ProductID
INNER JOIN Region rg
ON sls.RegionID = rg.RegionID
GROUP BY pr.ProductID, sls.SalesOrderID, rg.RegionID
HAVING COUNT(*) > 1;

-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 
SELECT sls.ProductID, YEAR(OrderDate) AS Year, SUM(Total) AS Fatturato_annuo, pr.ProductName
FROM Sales sls
INNER JOIN Product pr
ON sls.ProductID = pr.ProductID
GROUP BY sls.ProductID, YEAR(OrderDate), pr.ProductName
ORDER BY sls.ProductID;

-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
SELECT SUM(Total) AS Fatturato, State, YEAR(OrderDate)
FROM Sales sls
INNER JOIN Region rg
ON sls.RegionID = rg.RegionID
GROUP BY State, YEAR(OrderDate)
ORDER BY Fatturato DESC, YEAR(OrderDate) DESC;

-- 4.Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
SELECT SUM(Total) AS FATTURATO, sls.ProductID, ProductCategory
FROM Sales sls
INNER JOIN Product pr
ON sls.ProductID = pr.ProductID
GROUP BY sls.ProductID, ProductCategory
ORDER BY FATTURATO DESC;

-- 5.Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
SELECT pr.ProductID, pr.ProductName, COUNT(OrderQuantity)
FROM Product pr
LEFT JOIN Sales sls
ON pr.ProductID = sls.ProductID
GROUP BY pr.ProductID, pr.ProductName, sls.OrderQuantity
HAVING COUNT(OrderQuantity) = 0;

-- secondo approccio:verifichiamo quali prodotti non hanno un ordine di vendita.
SELECT pr.ProductID, pr.ProductName, sls.SalesOrderID
FROM Product pr
LEFT JOIN Sales sls
ON pr.ProductID = sls.ProductID
WHERE sls.SalesOrderID IS NULL;

-- 6.Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
SELECT sls.ProductID, ProductName, MAX(OrderDate) AS DataRecente
FROM Sales as sls
inner join product as pr 
on sls.productid = pr.productid
GROUP BY ProductName, sls.ProductID
ORDER BY sls.ProductID;



                                                                                             
                                                                                             
                                                                                             

                                                                                             

                                                        



																			
